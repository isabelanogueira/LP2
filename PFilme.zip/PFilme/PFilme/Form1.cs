﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; 
using System.Collections;

namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[10, 2];
            double media1 = 0, media2 = 0;
            int i = 0, j = 0, k = 1;
            string auxiliar = "";

            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 2; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota" + (j + 1) + " do Filme: " + (i+1)+";");

                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else if (notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                        media1 = media1 + Convert.ToDouble(notas[i, 0]);
                        media2 = media2 + Convert.ToDouble(notas[i, 1]);
                }
                lbxFilmes.Items.Add("Pessoa " + k++ + " - Nota Filme 1: " + notas[i, 0] + " Nota Filme 2: " + notas[i, 1] +
                        "\n");
            }
                media1 = media1 / 20;
                media2 = media2 / 10;
                lbxFilmes.Items.Add("\nMédia Filme 1: " + media1.ToString() + "\n\n" +
                                    "\nMédia Filme 2: " + media2.ToString());
             
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbxFilmes.Items.Clear();
        }
    }
}
