﻿namespace PMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.txtTexto1 = new System.Windows.Forms.TextBox();
            this.txtTexto2 = new System.Windows.Forms.TextBox();
            this.btnTestarIguais = new System.Windows.Forms.Button();
            this.btnInserirTxt = new System.Windows.Forms.Button();
            this.btnAsterisco = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(160, 74);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(55, 13);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1:";
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(160, 128);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(55, 13);
            this.lblPalavra2.TabIndex = 1;
            this.lblPalavra2.Text = "Palavra 2:";
            // 
            // txtTexto1
            // 
            this.txtTexto1.Location = new System.Drawing.Point(277, 67);
            this.txtTexto1.Name = "txtTexto1";
            this.txtTexto1.Size = new System.Drawing.Size(104, 20);
            this.txtTexto1.TabIndex = 2;
            // 
            // txtTexto2
            // 
            this.txtTexto2.Location = new System.Drawing.Point(277, 125);
            this.txtTexto2.Name = "txtTexto2";
            this.txtTexto2.Size = new System.Drawing.Size(104, 20);
            this.txtTexto2.TabIndex = 3;
            // 
            // btnTestarIguais
            // 
            this.btnTestarIguais.Location = new System.Drawing.Point(138, 228);
            this.btnTestarIguais.Name = "btnTestarIguais";
            this.btnTestarIguais.Size = new System.Drawing.Size(105, 82);
            this.btnTestarIguais.TabIndex = 4;
            this.btnTestarIguais.Text = "Testar Iguais";
            this.btnTestarIguais.UseVisualStyleBackColor = true;
            this.btnTestarIguais.Click += new System.EventHandler(this.btnTestarIguais_Click);
            // 
            // btnInserirTxt
            // 
            this.btnInserirTxt.Location = new System.Drawing.Point(321, 228);
            this.btnInserirTxt.Name = "btnInserirTxt";
            this.btnInserirTxt.Size = new System.Drawing.Size(105, 82);
            this.btnInserirTxt.TabIndex = 5;
            this.btnInserirTxt.Text = "Inserir Texto 1 no Texto 2";
            this.btnInserirTxt.UseVisualStyleBackColor = true;
            this.btnInserirTxt.Click += new System.EventHandler(this.btnInserirTxt_Click);
            // 
            // btnAsterisco
            // 
            this.btnAsterisco.Location = new System.Drawing.Point(502, 228);
            this.btnAsterisco.Name = "btnAsterisco";
            this.btnAsterisco.Size = new System.Drawing.Size(105, 82);
            this.btnAsterisco.TabIndex = 6;
            this.btnAsterisco.Text = "Inserir Asteriscos no Texto 1";
            this.btnAsterisco.UseVisualStyleBackColor = true;
            this.btnAsterisco.Click += new System.EventHandler(this.btnAsterisco_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(836, 529);
            this.Controls.Add(this.btnAsterisco);
            this.Controls.Add(this.btnInserirTxt);
            this.Controls.Add(this.btnTestarIguais);
            this.Controls.Add(this.txtTexto2);
            this.Controls.Add(this.txtTexto1);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.TextBox txtTexto1;
        private System.Windows.Forms.TextBox txtTexto2;
        private System.Windows.Forms.Button btnTestarIguais;
        private System.Windows.Forms.Button btnInserirTxt;
        private System.Windows.Forms.Button btnAsterisco;
    }
}