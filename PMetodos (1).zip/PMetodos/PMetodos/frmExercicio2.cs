﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnTestarIguais_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtTexto1.Text, txtTexto2.Text, true) == 0) //ignorecase=true
                MessageBox.Show("São Iguais!");
            else
                MessageBox.Show("São Diferentes!");
        }

        private void btnInserirTxt_Click(object sender, EventArgs e)
        {
            int meio = txtTexto2.Text.Length / 2;

            txtTexto2.Text = txtTexto2.Text.Substring(0, meio) + txtTexto1.Text + txtTexto2.Text.Substring(meio, txtTexto2.Text.Length - meio);
        }

        private void btnAsterisco_Click(object sender, EventArgs e)
        {
            int meio = txtTexto1.Text.Length / 2;
            txtTexto2.Text = txtTexto1.Text.Insert(meio, "**");
        }
    }
}
